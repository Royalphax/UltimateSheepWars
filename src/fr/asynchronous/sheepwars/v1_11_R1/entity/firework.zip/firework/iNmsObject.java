package fr.asynchronous.sheepwars.v1_11_R1.entity.firework;

public interface iNmsObject {
	
	/**
	 * Build
	 */
	public Object build()throws Exception;
}